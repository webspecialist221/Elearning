<!DOCTYPE html>
<html>

<head>
	<meta charset="UTF-8">
	<title>E Learning - Home</title>
	<link href="{{ asset('assets/css/bootstrap-theme.min.css')}}" rel="stylesheet" type="text/css" />
	<link href="{{ asset('assets/css/bootstrap.min.css')}}" rel="stylesheet" type="text/css" />
	<link href="{{ asset('assets/css/style.css')}}" rel="stylesheet" type="text/css" />
	<link href="{{ asset('assets/css/font-awesome.min.css')}}" rel="stylesheet" type="text/css" />
	<script src="{{ asset('assets/js/jquery.min.js')}}" type="text/javascript"></script>
	
	<style>
		@font-face {
			font-family: 'exo';
			src: url('assets/exo/Exo2.0-Regular.otf');
		}
		body, html{
			font-family: exo, sans-serif;
		}
	</style>
</head>
<body>
	<!-- <div class="container-fluid container-top-links">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<ul class="list-inline pull-right list-signup">
						<li><a href="#" class="text-capitalize">register</a></li>
						<li class="list-menu-separator">|</li>
						<li><a href="#" class="text-capitalize">login</a></li>
					</ul>
						<!-- <ul class="list-inline pull-right list-menu">
							<li><a href="#">FAQ</a></li>
							<li><a href="#" class="text-capitalize">blog</a></li>
							<li><a href="#" class="text-capitalize">about us</a></li>
							<li><a href="#" class="text-capitalize">shopping cart</a></li>
						</ul>
					</div>
				</div>
			</div>
		</div>  -->
		<div class="modal fade" id="navbar-links">
			<div class="modal-dialog">
				<div class="modal-content">
					<ul class="list-unstyled text-center list-links-media">
						<li><a href="{{url('/')}}" class="text-uppercase active">home</a></li>
						<!-- <li class="dropdown">
							<a href="" class="text-uppercase dropdown-toggle" data-toggle="dropdown">courses <span class="caret"></span></a>
							<ul class="dropdown-menu">
								<li><a href="#">Web Programming</a></li>
								<li><a href="#">Graphic Designing</a></li>
								<li><a href="#">Desktop Technology</a></li>
								<li><a href="#">Networking</a></li>
							</ul>                            
						</li> -->
						<!-- <li><a href="index.php" class="text-uppercase">certifications</a></li>
						<li><a href="index.php" class="text-uppercase">virtual labs</a></li>
						<li><a href="index.php" class="text-uppercase">corporate</a></li>
						<li><a href="index.php" class="text-uppercase">resources</a></li> -->
					</ul>
				</div>
			</div>
		</div>
		<div class="container-fluid">
			<nav class="container-links">
				<div class="container">
					<div class="navbar-header">
						<button class="navbar-toggle" data-toggle="modal" data-target="#navbar-links">
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						<a href="index.php" class="navbar-brand">
							<img src="{{ asset('assets/images/logo.png')}}" class="logo">
						</a>
					</div>
					<div class="collapse navbar-collapse">
						<ul class="nav navbar-nav navbar-right">
							<li><a href="{{url('/')}}" class="text-uppercase active">home</a></li>
							<!-- <li class="dropdown">
								<a href="index.php" class="text-uppercase dropdown-toggle" data-toggle="dropdown">courses <span class="caret"></span></a>
								<ul class="dropdown-menu">
								   <li><a href="#">Web Programming</a></li>
								   <li><a href="#">Graphic Designing</a></li>
								   <li><a href="#">Desktop Technology</a></li>
								   <li><a href="#">Networking</a></li>
							   </ul>  
						   </li> -->
							<!-- <li><a href="index.php" class="text-uppercase">certifications</a></li>
							<li><a href="index.php" class="text-uppercase">virtual labs</a></li>
							<li><a href="index.php" class="text-uppercase">corporate</a></li>
							<li><a href="index.php" class="text-uppercase">resources</a></li> -->
						</ul>
					</div>
				</div>
			</nav>

			<div class="row row-carousel">
				<div class="carousel slide" data-ride="carousel" id="banner-slider">
					<div class="carousel-inner">
						<div class="item active">
							<img src="{{ asset('assets/images/banner-slider.jpg')}}">
							<div class="carousel-caption">
								<div class="col-lg-8 pull-right">
									<div class="banner-content-inner pull-right">
										<h1 class="text-uppercase" style="font-family: Arial, sans-serif; font-size: 50px;"><span class="text-yellow" style="font-weight: 800;">advanced</span> <span class="text-white" style="font-weight: 800;">it</span><br><span class="text-white" style="font-weight: 800;">security</span> <span class="text-yellow" style="font-weight: 800;">skills</span></h1>
									</div>
									<h3 class="text-uppercase text-white txt-hide" style="font-family: Arial, sans-serif;"><b>for individuals & corporations</b></h3>
								</div>
							</div>
						</div>
						<div class="item">
							<img src="{{ asset('assets/images/banner-slider.jpg')}}">
							<div class="carousel-caption">
								<div class="col-lg-8 pull-right">
									<div class="banner-content-inner pull-right">
										<h1 class="text-uppercase" style="font-family: Arial, sans-serif; font-size: 50px;"><span class="text-yellow" style="font-weight: 800;">advanced</span> <span class="text-white" style="font-weight: 800;">it</span><br><span class="text-white" style="font-weight: 800;">security</span> <span class="text-yellow" style="font-weight: 800;">skills</span></h1>
									</div>
									<h3 class="text-uppercase text-white txt-hide" style="font-family: Arial, sans-serif;"><b>for individuals & corporations</b></h3>
								</div>
							</div>
						</div>
					</div>
					<a data-slide="prev" href="#banner-slider" class="left carousel-control hidden-xs"><span class="fa fa-caret-left fa-2x"></span></a>
					<a data-slide="next" href="#banner-slider" class="right carousel-control hidden-xs"><span class="fa fa-caret-right fa-2x"></span></a>
				</div>
			</div>
		</div> 	
		@yield('content')
		<div class="container-fluid footer">
			<div class="container">
				<div class="row">
					<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6 media-col">
						<img src="{{ asset('assets/images/logo.png')}}">
						<div class="row" style="margin-top: 35px;">
							<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">
								<i class="fa fa-phone fa-light"></i>
							</div>
							<div class="col-lg-10 col-md-10 col-sm-10 col-xs-10">
								<p class="text-white">(00) 123 45 789</p>
							</div>
						</div>
						<div class="row">
							<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">
								<i class="fa fa-phone fa-envelope fa-light"></i>
							</div>
							<div class="col-lg-10 col-md-10 col-sm-10 col-xs-10">
								<p class="text-white">mail@gmail.com</p>
							</div>
						</div>
						<div class="row">
							<div class="col-lg-12">
								<ul class="list-inline social-links">
									<li><a href="#"><i class="fa fa-facebook"></i></a></li>
									<li><a href="#"><i class="fa fa-twitter"></i></a></li>
									<li><a href="#"><i class="fa fa-google-plus"></i></a></li>
									<li><a href="#"><i class="fa fa-pinterest"></i></a></li>
								</ul>
							</div>
						</div>
					</div>
					<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6 media-col">
						<h4 class="text-white text-uppercase"><b>company</b></h4>
						<ul class="list-unstyled list-links">
							<li><a href="" class="text-white">Link1 </a></li>
							<li><a href="" class="text-white">Link1 </a></li>
							<li><a href="" class="text-white">Link1 </a></li>
							<li><a href="" class="text-white">Link1 </a></li>
							<li><a href="" class="text-white">Link1 </a></li>
						</ul>
					</div>
					<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6 media-col">
						<h4 class="text-white text-uppercase"><b>links</b></h4>
						<ul class="list-unstyled list-links">
							<li><a href="" class="text-white">Link1 </a></li>
							<li><a href="" class="text-white">Link1 </a></li>
							<li><a href="" class="text-white">Link1 </a></li>
							<li><a href="" class="text-white">Link1 </a></li>
							<li><a href="" class="text-white">Link1 </a></li>
						</ul>
					</div>
					<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6 media-col">
						<h4 class="text-white text-uppercase"><b>support</b></h4>
						<ul class="list-unstyled list-links">
							<li><a href="" class="text-white">Link1 </a></li>
							<li><a href="" class="text-white">Link1 </a></li>
							<li><a href="" class="text-white">Link1 </a></li>
							<li><a href="" class="text-white">Link1 </a></li>
							<li><a href="" class="text-white">Link1 </a></li>
						</ul>
					</div>
				</div>
				<hr style="margin-top: 55px; color: #515151;">
				<div class="row">
					<div class="col-md-6 col-md-offset-3">
						<p><small><span class="text-white">Designed by</span> <span class="text-yellow text-capitalize">information technology excellence center</span></small></p>
					</div>
					<div class="col-lg-7 col-md-7 col-sm-12 media-center"></div>
				</div>
			</div>
		</div>

		<script src="{{ asset('assets/js/bootstrap.min.js')}}" type="text/javascript"></script>
		<script>
			$('.carousel').carousel({
				pause: "false"
			});
		</script>
	</body>

	</html>