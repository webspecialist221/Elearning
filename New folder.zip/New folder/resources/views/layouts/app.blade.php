<!DOCTYPE html>
<html>

<!-- Mirrored from www.riaxe.com/marketplace/thin-admin/login.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 22 Apr 2016 06:52:31 GMT -->
<head>
<title>Admin-Elearning</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<!-- Bootstrap -->
<link href="{{asset('css/bootstrap.css')}}" rel="stylesheet" media="screen">
<link href="{{asset('css/thin-admin.css')}}" rel="stylesheet" media="screen">
<link href="{{asset('css/font-awesome.css')}}" rel="stylesheet" media="screen">
<link href="{{asset('style/style.css')}}" rel="stylesheet">



</head>
<body>
<div class="login-logo">
    <!-- <img src="{{asset('images/logo.png')}}" width="147" height="33"> -->
    <h2 style="color:white;">ELEARNING</h2> 
    </div>

    @yield('content')
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) --> 
<script src="{{asset('js/jquery.js')}}"></script> 
<script src="{{asset('js/bootstrap.min.js')}}"></script> 
<!--switcher html start-->

            
            
    <!--switcher html end-->
<script src="{{asset('assets/switcher/switcher.js')}}"></script> 
<script src="{{asset('assets/switcher/moderziner.custom.js')}}"></script> 
<link href="{{asset('assets/switcher/switcher.css')}}" rel="stylesheet">
<link href="{{asset('assets/switcher/switcher-defult.css')}}" rel="stylesheet">
<link rel="alternate stylesheet" type="text/css" href="{{asset('assets/switcher/a.css')}}" title="a" media="all" />
<link rel="alternate stylesheet" type="text/css" href="{{asset('assets/switcher/b.css')}}" title="b" media="all" />
<link rel="alternate stylesheet" type="text/css" href="{{asset('assets/switcher/c.css')}}" title="c" media="all" />
<link rel="alternate stylesheet" type="text/css" href="{{asset('assets/switcher/d.css')}}" title="d" media="all" />
<link rel="alternate stylesheet" type="text/css" href="{{asset('assets/switcher/e.css')}}" title="e" media="all" />
<link rel="alternate stylesheet" type="text/css" href="{{asset('assets/switcher/f.css')}}" title="f" media="all" />
<link rel="alternate stylesheet" type="text/css" href="{{asset('assets/switcher/g.css')}}" title="g" media="all" />
<link rel="alternate stylesheet" type="text/css" href="{{asset('assets/switcher/h.css')}}" title="h" media="all" />
<link rel="alternate stylesheet" type="text/css" href="{{asset('assets/switcher/i.css')}}" title="i" media="all" />
<link rel="alternate stylesheet" type="text/css" href="{{asset('assets/switcher/j.css')}}" title="j" media="all" />

</body>

<!-- Mirrored from www.riaxe.com/marketplace/thin-admin/login.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 22 Apr 2016 06:52:31 GMT -->
</html>
