@extends('layout.admin-master')

@section('content')
<div class="page-content" >
    <div class="content container" style="min-height:515px;">
      <div class="row">
        <div class="col-lg-12">
          <h2 class="page-title">Dashboard <small>Statistics and more</small></h2>
      </div>
  </div>
  <div class="row">
    <div class="col-md-12">
      <div class="row">
        <div class="col-md-3 col-xs-12 col-sm-6"> <a href="#" class="stats-container">
          <div class="stats-heading">Profit</div>
          <div class="stats-body-alt"> 
             
            <div class="text-center"><span class="text-top">$</span>345</div>
            <small>+4.7% from last period</small> </div>
            <div class="stats-footer">more info</div>
        </a> </div>
        <div class="col-md-3 col-xs-12 col-sm-6"> <a href="#" class="stats-container">
          <div class="stats-heading">Revenue</div>
          <div class="stats-body-alt"> 
             
            <div class="text-center"><span class="text-top">$</span>34.7k</div>
            <small>-14.7% from last week</small> </div>
            <div class="stats-footer">go to account</div>
        </a> </div>
        <div class="col-md-3 col-xs-12 col-sm-6"> <a href="#" class="stats-container">
          <div class="stats-heading">Members</div>
          <div class="stats-body-alt"> 
             
            <div class="text-center"><span class="text-top"></span>207</div>
            <small>new user registered</small> </div>
            <div class="stats-footer">manage members</div>
        </a> </div>
        <div class="col-md-3 col-xs-12 col-sm-6"> <a href="#" class="stats-container">
          <div class="stats-heading">Orders</div>
          <div class="stats-body-alt"> 
           
            <div class="text-center"><span class="text-top">$</span>345</div>
            <small>new orders received</small> </div>
            <div class="stats-footer">manage orders</div>
        </a> </div>
    </div>
</div>
</div>



<div class="row">
  <div class="col-lg-4"> 
    <!--new earning start-->
    <div class="panel terques-chart">
      <div class="panel-body chart-texture">
        <div class="chart">
          <div class="heading"> <span>Friday</span> <strong>$ 48,00 | 13%</strong> </div>
          <div class="sparkline" data-type="line" data-resize="true" data-height="90" data-width="90%" data-line-width="1" data-line-color="#fff" data-spot-color="#fff" data-fill-color="" data-highlight-line-color="#fff" data-spot-radius="4" data-data="[200,135,667,333,526,996,564,123,890,564,455]"></div>
      </div>
  </div>
  <div class="chart-tittle"> <span class="title">New Earning</span> <span class="value-pie"> <a href="#" class="active">Market</a> | <a href="#">Referal</a> | <a href="#">Online</a> </span> </div>
</div>
<!--new earning end--> 
</div>
<div class="col-lg-4"> 
    <!--total earning start-->
    <div class="panel green-chart">
      <div class="panel-body">
        <div class="chart">
          <div class="heading"> <span>June</span> <strong>18 Days | 55%</strong> </div>
          <div id="barchart"></div>
      </div>
  </div>
  <div class="chart-tittle"> <span class="title">Total Earning</span> <span class="value-pie">$, 85,34,577</span> </div>
</div>
<!--total earning end--> 
</div>
<div class="col-lg-4"> 
    <!--pie chart start-->
    <div class="panel">
      <div class="panel-body text-center">
        <div class="chart" style="height: 110px;">
          <div id="pie-chart" ></div>
      </div>
  </div>
  <div class="chart-tittle"> Free: 240GB </div>
</div>
<!--pie chart start--> 
</div>
</div>



</div>
</div>
@endsection