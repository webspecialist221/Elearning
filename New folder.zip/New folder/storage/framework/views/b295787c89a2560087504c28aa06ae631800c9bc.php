<?php $__env->startSection('content'); ?>

<div class="page-content">
	<div class="content container" style="min-height:515px;">
        <div class="row">
		<div class="col-md-8 col-md-offset-2">
			<div class="widget">
				<div class="widget-header"> <i class="icon-align-left"></i>
					<h3>Add Playlist </h3>
				</div>
				<div class="widget-content">
					<?php echo Form::open(['url' => 'playlist_form']); ?>

						<fieldset>
							<!-- <legend class="section">Horizontal form</legend> -->

							<div class="control-group">
								<div class="col-md-3">
									<?php echo Form::label('name', "Technology Name: ",['class'=>'control-label']); ?>

								</div>
								<div class="col-md-9">
									<div class="form-group">
					                <?php echo Form::text('name', null , ['class' => 'form-control','id'=>'name'] ); ?>					
									</div>
								</div>
							</div>
							<div class="control-group">
								<div class="col-md-3">
									<?php echo Form::label('playlist', "Playlist Id: ",['class'=>'control-label']); ?>

								</div>
								<div class="col-md-9">
									<div class="form-group">
										<?php echo Form::text('playlist_id', null , ['class' => 'form-control','id'=>'playlist'] ); ?>

									</div>
								</div>
							</div>
							
							</fieldset>
								<div class="form-actions">
									<div>
										<?php echo Form::submit('submit', ['class' => 'btn btn-primary','id'=>'playlist'] ); ?>

									</div>
								</div>
							<?php echo Form::close(); ?>

						</div>
					</div>
				</div>
                </div>
			</div>
		</div>		
		<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin-master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>