<?php $__env->startSection('content'); ?>
<div class="page-content">
  	<div class="content container" style="min-height:515px;">
		<div class="row">
            <div class="col-md-10 col-md-offset-1">
          <div class="widget">
            <div class="widget-header"> <i class="icon-eye-open"></i>
              <h3>View All Playlist</h3>
            </div>
            <div class="widget-content">
              <table class="table table-hover">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>PlayList Id</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  <?php foreach($records as $record): ?>
                  <tr>
                    <td><?php echo e($record->id); ?></td>
                    <td><?php echo e($record->name); ?></td>
                    <td><?php echo e($record->playlist_id); ?></td>
                    <td>
                      <a href="#" class="btn btn-danger"><i class="icon-trash"></i></a>
                    </td>
                  </tr>
                  <?php endforeach; ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>    
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin-master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>