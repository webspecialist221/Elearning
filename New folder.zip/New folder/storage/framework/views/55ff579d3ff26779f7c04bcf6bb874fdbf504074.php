<?php $__env->startSection('content'); ?>
<div class="page-content">
	<div class="content container">
		<div class="row">
			<div class="col-lg-12">
				<h2 class="page-title">Dashboard <small>Statistics and more</small></h2>
			</div>
		</div>
	</div>	
</div>

<?php $__env->stopSection(); ?>  
<?php echo $__env->make('layout.admin-master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>