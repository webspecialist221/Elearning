var defaulttext = $('.default-text').text();

$('.selectDefault').text(defaulttext);

$('.selectBox').on('change', function () {
    var defaulttext2 = $('.selectBox').find(":selected").text();
    $('.selectDefault').text(defaulttext2);
});

var defaulttext = $('.default-text1').text();

$('.selectDefault1').text(defaulttext);

$('.selectBox1').on('change', function () {
    var defaulttext2 = $('.selectBox1').find(":selected").text();
    $('.selectDefault1').text(defaulttext2);
});

var defaulttext = $('.default-text2').text();

$('.selectDefault2').text(defaulttext);

$('.selectBox2').on('change', function () {
    var defaulttext2 = $('.selectBox2').find(":selected").text();
    $('.selectDefault2').text(defaulttext2);
});

var defaulttext = $('.default-text3').text();

$('.selectDefault3').text(defaulttext);

$('.selectBox3').on('change', function () {
    var defaulttext2 = $('.selectBox3').find(":selected").text();
    $('.selectDefault3').text(defaulttext2);
});

var defaulttext = $('.default-text4').text();

$('.selectDefault4').text(defaulttext);

$('.selectBox4').on('change', function () {
    var defaulttext2 = $('.selectBox4').find(":selected").text();
    $('.selectDefault4').text(defaulttext2);
});

var defaulttext = $('.default-text5').text();

$('.selectDefault5').text(defaulttext);

$('.selectBox5').on('change', function () {
    var defaulttext2 = $('.selectBox5').find(":selected").text();
    $('.selectDefault5').text(defaulttext2);
});

var defaulttext = $('.default-text6').text();

$('.selectDefault6').text(defaulttext);

$('.selectBox6').on('change', function () {
    var defaulttext2 = $('.selectBox6').find(":selected").text();
    $('.selectDefault6').text(defaulttext2);
});

var defaulttext = $('.default-text7').text();

$('.selectDefault7').text(defaulttext);

$('.selectBox7').on('change', function () {
    var defaulttext2 = $('.selectBox7').find(":selected").text();
    $('.selectDefault7').text(defaulttext2);
});

var defaulttext = $('.default-text8').text();

$('.selectDefault8').text(defaulttext);

$('.selectBox8').on('change', function () {
    var defaulttext2 = $('.selectBox8').find(":selected").text();
    $('.selectDefault8').text(defaulttext2);
});

var defaulttext = $('.default-text9').text();

$('.selectDefault9').text(defaulttext);

$('.selectBox9').on('change', function () {
    var defaulttext2 = $('.selectBox9').find(":selected").text();
    $('.selectDefault9').text(defaulttext2);
});

var defaulttext = $('.default-text10').text();

$('.selectDefault10').text(defaulttext);

$('.selectBox10').on('change', function () {
    var defaulttext2 = $('.selectBox10').find(":selected").text();
    $('.selectDefault10').text(defaulttext2);
});